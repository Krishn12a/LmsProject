export default test = {
    laptops : [
        {
            id:1,
            image_path:'dasaf/dadsdz/ada/',
            price:2500,
            name:'hp laptop 1'
        },
        {

        }
    ]
}