import React from 'react'

const LaptopComp = () => {
    return (
        <div>
            
        </div>
    )
}

export default LaptopComp
